# Register the weekly Sunday Schwab-token refresh as a Windows Scheduled Task.
# Runs 'spxgo.exe -token' from THIS folder every Sunday at 8:00 AM (interactive:
# a console opens so you can log in to Schwab and paste the redirect URL).
#
#   Right-click -> Run with PowerShell     (or)     .\install_token_task.ps1
#
# To remove it later:  Unregister-ScheduledTask -TaskName 'SPX_GO Weekly Token' -Confirm:$false

$ErrorActionPreference = "Stop"
$exe = Join-Path $PSScriptRoot "spxgo.exe"
if (-not (Test-Path $exe)) {
    Write-Host "spxgo.exe not found in $PSScriptRoot — run .\build.ps1 first." -ForegroundColor Red
    exit 1
}

$action    = New-ScheduledTaskAction -Execute $exe -Argument "-token" -WorkingDirectory $PSScriptRoot
$trigger   = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At 8:00am
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
$settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 1)

Register-ScheduledTask -TaskName "SPX_GO Weekly Token" -Action $action -Trigger $trigger `
    -Principal $principal -Settings $settings -Description "Weekly Schwab token refresh for SPX_GO (interactive login)." -Force | Out-Null

Write-Host "Installed scheduled task 'SPX_GO Weekly Token' — runs Sundays 8:00 AM." -ForegroundColor Green
Write-Host "It will open a window to log in to Schwab each week. Run it now to test:"
Write-Host "   Start-ScheduledTask -TaskName 'SPX_GO Weekly Token'"

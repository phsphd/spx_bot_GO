# SPX_GO — single-binary SPX signal copier (Go)

Receives SPX options signals from the excellgen relay and places the matching trades on the
end-user's own Schwab account. **One `spxgo.exe`, no Python, no runtime** — built for
non-technical users who just run PowerShell.

- **`python/`** — the reference Python implementation (dev/parity).
- **this folder** — the Go bot (the shipping product).

## Two commands (that's the whole interface)

```powershell
.\spxgo.exe -token     # weekly (e.g. Sunday): authorize with Schwab, refresh the 7-day token
.\spxgo.exe            # run: reads .env / config.json, dry-run or (armed) real trading
```

- `-token` runs the interactive Schwab OAuth flow (opens the browser, you paste the redirect
  URL back) and saves the token file. Schwab refresh tokens last 7 days, so run it weekly.
- With no flag it reads config, validates the license, listens for SPX signals, places orders
  (demo = logged only), prints per-minute P/L, and flattens at end of day.

## Build

```powershell
.\build.ps1            # -> spxgo.exe (self-contained). Deps are vendored, builds offline.
```

## Config

Use **either** `.env` or `config.json` (copy the `.example`). Environment variables override
`config.json`. Key settings: `SPXGO_LICENSE_TOKEN`, `SPXGO_MODE` (demo/real),
`SCHWAB_TOKEN_FILE`, `SPXGO_MAX_CONTRACTS`, and the EOD times. See `.env.example`.

**Real money needs all three:** `SPXGO_MODE=real` + `SPXGO_LIVE_TRADE=on` + `SPXGO_REAL_CONFIRM=on`.

## What it does

| Feature | Detail |
|---|---|
| Receive | WebSocket to `wss://shop.excellgen.com/websk?token=<LICENSE>`, SPX-filtered |
| Place | Schwab multi-leg order (OPEN sells/buys-to-open; CLOSE flips) |
| Dry-run P/L | every minute: each position + total, marked from **live Schwab option quotes** |
| EOD | flatten at 15:45 ET unless every short strike ≥1% OTM; hard cutoff 15:58 |
| License | validated at connect + re-checked every 30 days; revoked token stops trading |
| Token | reuses the shared `schwab_tokens.json`; `-token` refreshes it weekly |

## Layout

```
main.go              flag parse (-token vs run) + orchestration loop
internal/config      .env / config.json loader
internal/schwab      auth.go (OAuth + refresh + -token), client.go (orders/positions/quotes)
internal/relay       gorilla/websocket listener
internal/sig         signal struct + Schwab order translation
internal/pnl         dry-run P/L compute + console report
internal/eod         end-of-day flatten guard
internal/license     /webhk/license check
```

Tested: `go test ./...` (order translation flip + P/L math verified — same numbers as Python).

**End users:** see `USER_GUIDE.md`.

# SPX_GO — End-User Guide (no coding required)

SPX_GO is a single program (`spxgo.exe`) that receives SPX options trade signals and places
the trades in **your own Charles Schwab account**. You run it from Windows PowerShell — no
Python, no programming.

> ⚠️ Options trading is real financial risk. Start in **Demo**. Real trading is off until you
> deliberately turn on three switches. You are responsible for your account and trades.

## What you need
1. A **Schwab brokerage account** with options (spreads) approved.
2. A free **Schwab Developer app** (Step 1 below).
3. Your **license token** (from your provider).
4. The **`spxgo.exe`** file + a `.env` (or `config.json`) in the same folder.

---

## Step 1 — Create your Schwab API app (one time)
1. Go to **https://developer.schwab.com**, create an account, sign in.
2. **Create App** → select **Accounts and Trading Production** *and* **Market Data Production**.
3. **Callback URL**: enter exactly `https://127.0.0.1` (you'll reuse this).
4. Submit and wait for status **Ready For Use** (Schwab approval can take a few days).
5. Open the app and copy your **App Key** and **Secret**.

Create a file named `schwab_tokens.json` (the guide/provider can give you a template) with:
```json
{ "AppKey": "YOUR_APP_KEY", "Secret": "YOUR_SECRET", "RedirectUri": "https://127.0.0.1" }
```
Point `SCHWAB_TOKEN_FILE` in your `.env` at that file.

---

## Step 2 — Get your Schwab login token (and every Sunday after)
In PowerShell, in the folder with `spxgo.exe`:
```powershell
.\spxgo.exe -token
```
- Your browser opens to Schwab. **Log in and approve.**
- Schwab sends you to a `https://127.0.0.1/?code=...` page that **won't load — that's normal.**
- **Copy the full address-bar URL** and paste it back into the PowerShell window, press Enter.
- It saves your token. ✔

**Do this once a week (e.g. every Sunday)** — Schwab tokens expire after 7 days.

---

## Step 3 — Configure
Copy `.env.example` to `.env` and set at least:
```
SPXGO_LICENSE_TOKEN=<your license token>
SPXGO_MODE=demo
SCHWAB_TOKEN_FILE=C:\path\to\schwab_tokens.json
```

## Step 4 — Run in Demo (watch, no real trades)
```powershell
.\spxgo.exe
```
It checks your license and listens. **Every minute** it prints your (simulated) positions and
profit/loss, priced from **live Schwab quotes**:
```
===== SPX_GO DRY-RUN P/L  14:30 ET =====
  KIND          TYPE  STRIKES     QTY   ENTRY    MARK      P/L $
  credit_spread PUT   5980/5950     3   -1.50   -0.65    +255.00
  ----------------------------------------------------------
                                   TOTAL OPEN P/L: $+255.00
```
Watch it for a few days until you trust it.

## Step 5 — Go Live (real money)
In `.env` set **all three**:
```
SPXGO_MODE=real
SPXGO_LIVE_TRADE=on
SPXGO_REAL_CONFIRM=on
SPXGO_MAX_CONTRACTS=5     # hard cap per order — never exceeded
```
Restart `.\spxgo.exe`. It now places real Schwab orders when signals arrive.

## End-of-day
It closes your positions at **3:45 PM ET** unless every short strike is ≥1% out-of-the-money,
and never holds anything past **3:58 PM ET**.

## Automate the weekly token (optional)
Easiest — run the installer once (it points the task at this folder automatically):
```powershell
.\install_token_task.ps1
```
This creates a Windows scheduled task **"SPX_GO Weekly Token"** that runs `spxgo.exe -token`
every **Sunday at 8:00 AM**. A window opens so you can log in to Schwab and paste the redirect
URL (Schwab requires a login each week — this can't be fully automatic).

Prefer to import the XML by hand? Use `SPX_GO_weekly_token.xml`:
```powershell
schtasks /create /tn "SPX_GO Weekly Token" /xml .\SPX_GO_weekly_token.xml
```
(edit the `<Command>`/`<WorkingDirectory>` paths in the XML if your folder differs).

## Troubleshooting
| Message | Fix |
|---|---|
| `License check FAILED` | Check `SPXGO_LICENSE_TOKEN` / ask your provider. |
| `no RefreshToken — run spxgo.exe -token` | Run the weekly token step. |
| `P/L monitor unavailable` | Token missing/expired → `.\spxgo.exe -token`. |
| Orders not placing (live) | Confirm all three: `SPXGO_MODE=real`, `SPXGO_LIVE_TRADE=on`, `SPXGO_REAL_CONFIRM=on`. |

Your App Key/Secret and Schwab token **stay on your computer** — the provider only ever sees
your license token.
